#01
setwd("C:/Users/IT24102960/Desktop/Lab 4")

branch_data <- read.table("Exercise.txt", header = TRUE,sep = ",")
head(branch_data)
fix(data)
branch_data

#02
str(branch_data)
summary(branch_data)
attach(branch_data)


#03

names(branch_data)


boxplot(Sales_X1,
        main = "Boxplot of Sales",
        outline = TRUE,
        outpch = 1,
        horizontal = TRUE)

#04
summary(branch_data$Advertising_X2)
IQR(branch_data$Advertising_X2)

#05
get.outliers <- function(z) {
  q1 <- quantile(z)[2]
  q3 <- quantile(z)[4]
  
  iqr <- q3 - q1
  
  ub <- q3 + 1.5 * iqr
  ib <- q1 - 1.5 * iqr
  
  print(paste("Upper Bound =", ub))
  print(paste("Lower Bound =", ib))
  
  outliers <- sort(z[z < ib | z > ub])
  
  if (length(outliers) > 0) {
    print(paste("Outliers:", paste(outliers, collapse = ",")))
  } else {
    print("No outliers detected.")
  }
}
get.outliers(branch_data$Years_X3)